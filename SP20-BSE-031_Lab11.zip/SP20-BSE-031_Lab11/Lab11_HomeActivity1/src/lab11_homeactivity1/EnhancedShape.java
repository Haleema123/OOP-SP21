
package lab11_homeactivity1;
public interface EnhancedShape extends Shape
{
   
}
