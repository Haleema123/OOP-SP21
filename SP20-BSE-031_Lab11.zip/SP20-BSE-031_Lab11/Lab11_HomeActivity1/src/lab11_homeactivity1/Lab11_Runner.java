
package lab11_homeactivity1;
public class Lab11_Runner
{
    public static void main(String[] args) 
    {
        Circle c = new Circle(2);
        System.out.println(c.perimeter());
    }   
}
