
package lab11_homeactivity1;
public interface Shape
{
    public double perimeter();  
}
