
package lab11_assignmentq1;
public interface Shape 
{
   public double area();
}
