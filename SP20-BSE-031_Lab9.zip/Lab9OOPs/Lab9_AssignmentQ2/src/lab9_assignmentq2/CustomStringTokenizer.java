
package lab9_assignmentq2;

import java.util.StringTokenizer;

public class CustomStringTokenizer extends StringTokenizer
{
    public String token;  

    public CustomStringTokenizer(String token)
    {
        super(token);
        this.token = token;
    }
    
    @Override
    public int countTokens()
    { 
        String [] b = new String[super.countTokens()];
        int i =0;
        while (this.hasMoreTokens()) 
        {
            b[i]=this.nextToken();  
            i++; 
        }  
        int count=0;
        String[] s = {"1","2","3","4","5","6","7","8","9"};
        for (int I=0; I<b.length; I++)
        {
            boolean bol = true;
            for(int j=0; j<s.length; j++)
            {
               if(b[I].contains(s[j]))
               {
                   bol =false;
               }
            }
            
            if(bol)
            {
                count++;
            }
        }   
        return count;
        
    }
}
