
package lab9_assignmentq2;
public class lab9_assignmentq2_Runner
{
     public static void main(String[] args) 
    {
        CustomStringTokenizer a = new CustomStringTokenizer( "I have 10 animals");
        System.out.println("Count: "+a.countTokens());
    }   
}
