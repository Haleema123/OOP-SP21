
package lab9_assignmentq1;

public class lab9_assignmentq1_Runner 
{
    public static void main(String[] args)
    {
        ClockExtended clock = new ClockExtended(45, 4, 6);
        clock.display();
    }
    
}
