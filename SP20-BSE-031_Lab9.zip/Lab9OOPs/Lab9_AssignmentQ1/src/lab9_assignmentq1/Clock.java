package lab9_assignmentq1;

public class Clock 
{

    public int TimeInHours;
    public int TimeInMin;
    public int TimeInSec;

    public Clock(int TimeInHours, int TimeInMin, int TimeInSec) 
    {
        this.TimeInHours = TimeInHours;
        this.TimeInMin = TimeInMin;
        this.TimeInSec = TimeInSec;
    }

    public void display() 
    {
        if (TimeInHours <= 24 & TimeInMin < 60 & TimeInSec < 60) 
        {
            System.out.println(TimeInHours+ ":" + TimeInMin+":" + TimeInSec+" hrs");
        }
        else 
        {
            System.out.println("Invalid Time Entered....Time should be less than 24:59:59 ");
        }

    }

}
