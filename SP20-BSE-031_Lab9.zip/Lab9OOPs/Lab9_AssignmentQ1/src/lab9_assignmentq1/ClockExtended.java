
package lab9_assignmentq1;
public class ClockExtended extends Clock
{

    public ClockExtended(int TimeInHours, int TimeInMin, int TimeInSec) 
    {
        super(TimeInHours, TimeInMin, TimeInSec);
    }
    
    public void display()
    {
        if (TimeInHours<=24 & TimeInMin<60 & TimeInSec<60)
        {
            if(TimeInHours<12 || TimeInHours==24)
            {
                System.out.println(TimeInHours + ":" + TimeInMin + ":" + TimeInSec+" AM");
            }
            else if(TimeInHours>=12 && TimeInHours<24)
            {
                System.out.println(TimeInHours %12 + ":" + TimeInMin + ":" + TimeInSec +" PM");
            }
        } 
        super.display();
        
    }    
}
