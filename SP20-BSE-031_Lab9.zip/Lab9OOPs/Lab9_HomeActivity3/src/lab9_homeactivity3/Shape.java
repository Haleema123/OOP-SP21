
package lab9_homeactivity3;
public abstract class Shape 
{
    public int NumberOfLinesInAShape;
    public String PenColor;
    public String FillColor;
    
    public Shape(int NOL, String PC, String FC)
    {
        NumberOfLinesInAShape = NOL;
        PenColor = PC;
        FillColor = FC;   
    }
    
    public abstract void draw();
    
}
