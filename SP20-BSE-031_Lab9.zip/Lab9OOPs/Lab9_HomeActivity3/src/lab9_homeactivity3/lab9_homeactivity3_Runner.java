
package lab9_homeactivity3;

public class lab9_homeactivity3_Runner
{
    public static void main(String[] args) 
    {
        Triangle triangle = new Triangle(4,"Pink","Black");
        triangle.draw();
        
        Circle circle = new Circle(5,"Violet","Yellow");
        circle.draw();
        
        Square square = new Square(9,"Red","Blue");
        square.draw();
       
    }
    
}
