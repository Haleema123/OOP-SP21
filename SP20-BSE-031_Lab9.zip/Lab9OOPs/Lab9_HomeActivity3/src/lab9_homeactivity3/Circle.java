
package lab9_homeactivity3;
public class Circle extends Shape
{
   
    public Circle(int NOL, String PC, String FC)
    {
        super(NOL, PC, FC);
    }
    
    public void draw()
    {
        System.out.println("\t\tCIRCLE\n"+"Number of lines: "+NumberOfLinesInAShape+"\nPen Color: "+PenColor+"\nFill Color: "+ FillColor);   
    }   
}
