
package lab9_homeactivity3;
public class Triangle extends Shape
{
    public Triangle(int NOL, String PC, String FC)
    {
        super(NOL, PC, FC);
    }
    
    public void draw()
    {
        System.out.println("\t\tTRIANGLE\n"+"Number of lines: "+NumberOfLinesInAShape+"\nPen Color: "+PenColor+"\nFill Color: "+ FillColor);   
    }   
    
}
