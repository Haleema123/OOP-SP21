
package lab9_homeactivity3;

public class Square extends Shape
{
    public Square(int NOL, String PC, String FC)
    {
        super(NOL, PC, FC);
    }
    
    public void draw()
    {
        System.out.println("\t\tSQUARE\n"+"Number of lines: "+NumberOfLinesInAShape+"\nPen Color: "+PenColor+"\nFill Color: "+ FillColor);   
    }   
    
}
