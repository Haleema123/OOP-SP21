
package lab9_homeactivity1;

import java.util.Scanner;

public class lab9_homeactivity1_Runner
{
    public static void main(String[] args) 
    {
        Action a2 = new Action(4, 3, "xyz");
        Drama a3 = new Drama(2, 5, "hhh");
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of days a Movie is late: ");
        int days = input.nextInt();
        System.out.println("Are Movies Equal? "+a2.equals(a3));
        System.out.println("The Late Fee is "+a3.calcLateFees(days));  
    }
    
    
}
