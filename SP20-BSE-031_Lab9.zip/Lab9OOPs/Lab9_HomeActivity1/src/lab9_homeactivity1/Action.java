
package lab9_homeactivity1;
public class Action extends Movie
{
    public Action(double rating, int IDNUMBER,String title)
    {
        super(rating,IDNUMBER, title);
    }
    
    public double calcLateFees(int days)
    {
        double Latefee = 3 * days;
        return Latefee;   
    }  
    
}
