
package lab9_homeactivity1;
public class Drama extends Movie
{
    public Drama(double rating, int IDNUMBER,String title)
    {
        super(rating,IDNUMBER, title);
    }
   
    public double calcLateFees(int days)
    {
        double Latefee = 2 * days;
        return Latefee;   
    }  
}
