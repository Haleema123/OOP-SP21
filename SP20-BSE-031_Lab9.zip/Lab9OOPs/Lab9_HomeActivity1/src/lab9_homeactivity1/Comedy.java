
package lab9_homeactivity1;
public class Comedy extends Movie
{
    public Comedy(double rating, int IDNUMBER,String title)
    {
        super(rating,IDNUMBER, title);
        
    }
    public double calcLateFees(int days)
    {
        double Latefee = 2.50 * days;
        return Latefee;   
    }  
}
