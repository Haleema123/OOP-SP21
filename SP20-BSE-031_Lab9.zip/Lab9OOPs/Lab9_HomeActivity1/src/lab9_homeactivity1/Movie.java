package lab9_homeactivity1;
import java.util.Scanner;
public class Movie
{
    private double rating;
    private int IDNUMBER;
    private String title;
   
    public Movie(double rating, int IDNUMBER,String title)
    {
        this.rating = rating;
        this.IDNUMBER = IDNUMBER;
        this.title = title; 
    }
    
    public void SetRating(double rating)
    {
        this.rating = rating;
    }
    
    public void SetIDNUMBER(int IDNUMBER)
    {
        this.IDNUMBER = IDNUMBER;
    }
    
    public void SetTitle(String title)
    {
        this.title = title;
    }

    public double getRating() 
    {
        return rating;
    }

    public int getIDNUMBER()
    {
        return IDNUMBER;
    }

    public String getTitle()
    {
        return title;
    }
    @Override
    public boolean equals(Object a1)
    {
        Movie a = (Movie)a1;
        if (IDNUMBER==a.IDNUMBER)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public double calcLateFees(int days)
    {
        double Latefee = 2 * days;
        return Latefee;   
    }  
}
