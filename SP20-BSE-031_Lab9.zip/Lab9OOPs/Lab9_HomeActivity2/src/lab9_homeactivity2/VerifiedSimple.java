
package lab9_homeactivity2;
public class VerifiedSimple extends Simple
{
    public VerifiedSimple(int number1, int number2)
    {
        super(number1, number2);
    }
    
     public void add()
    {
        if (getNumber1()>0 & getNumber2()>0)
        {
            super.add();
        }
        else
        {
            System.out.print("Error!!");
        }
    }
    public void sub()
    {
        if (getNumber1()>0 & getNumber2()>0)
        {
            super.sub();
        }
        else
        {
            System.out.print("Error!!");
        }
    }
    public void mul()
    {
        if (getNumber1()>0 & getNumber2()>0)
        {
            super.mul();
        }
        else
        {
            System.out.print("Error!!");
        }
    }
    public void div()
    {
        if (getNumber1()>0 & getNumber2()>0)
        {
            super.div();
        }
        else
        {
            System.out.print("Error!!");
        }
    }
   
    
}
