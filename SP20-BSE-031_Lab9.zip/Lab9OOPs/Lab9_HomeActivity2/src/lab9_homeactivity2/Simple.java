
package lab9_homeactivity2;
public class Simple 
{
    private int number1;
    private int number2;

    
    
    public Simple(int number1, int number2)
    {
        this.number1 = number1;
        this.number2 = number2;
    }

    public void setNumber1(int number1)
    {
        this.number1 = number1;
    }
    public int getNumber1()
    {
        return number1;
    }
    public void setNumber2(int number2) 
    {
        this.number2 = number2;
    }
    public int getNumber2()
    {
        return number2;
    }
    
    public void add()
    {
        int Add = getNumber1() + getNumber2();
        System.out.println("The sum of  number "+ number1+" and "+number2 +" is "+Add);
    }
    public void sub()
    {
        int Sub = getNumber1() - getNumber2();
        System.out.println("The sunbtraction of number " + number1+" and "+number2 +" is "+Sub);
    }
    public void mul()
    {
        int Mul = getNumber1() * getNumber2();
        System.out.println("The multiplication of number "+ number1+" and "+number2 +" is "+Mul);
    }
    public void div()
    {
        int Div = getNumber1() / getNumber2();
        System.out.println("The division of number "+ number1+" and "+number2 +" is "+Div);
    }
   
    
    
    
}
