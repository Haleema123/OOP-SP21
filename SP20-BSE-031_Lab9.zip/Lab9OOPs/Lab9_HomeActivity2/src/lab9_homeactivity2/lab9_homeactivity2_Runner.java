
package lab9_homeactivity2;
public class lab9_homeactivity2_Runner 
{
    public static void main(String[] args) 
    {
        VerifiedSimple a = new VerifiedSimple(1,2);
        a.add();
        
    }
    
}
