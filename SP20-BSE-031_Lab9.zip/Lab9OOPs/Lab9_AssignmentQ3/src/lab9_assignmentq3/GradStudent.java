
package lab9_assignmentq3;
public class GradStudent extends Student
{
    public void exam()
    {
        System.out.println("Graduate Student takes exam by written paper ");
    }
    
}
