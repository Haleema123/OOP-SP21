
package lab9_assignmentq3;
public abstract class Student 
{
    public abstract void exam();   
}
