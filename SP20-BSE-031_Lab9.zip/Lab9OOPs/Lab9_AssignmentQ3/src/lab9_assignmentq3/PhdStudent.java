
package lab9_assignmentq3;
public class PhdStudent extends Student
{
    public void exam()
    {
        System.out.println("Phd Student takes exam by giving his final defense presentation ");
    }
    
}
