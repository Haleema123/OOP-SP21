
package lab9_assignmentq3;
public class lab9_assignmentq3_Runner 
{
    public static void main(String[] args)
    {
        PhdStudent phdStudent = new PhdStudent();
        GradStudent gradStudent = new GradStudent();
        phdStudent.exam();
        gradStudent.exam();
        
    }
    
}
